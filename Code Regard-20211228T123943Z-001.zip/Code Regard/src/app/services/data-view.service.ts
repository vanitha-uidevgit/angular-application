import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})

export class DataViewService {
    public dataView$: BehaviorSubject<any> = new BehaviorSubject(null);

    getViewData(data: any) {
        this.dataView$.next(data);
    }

}