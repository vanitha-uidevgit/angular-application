import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import sidebarJsonUrl from '../../assets/jsondata/sidebar.json'

@Injectable({
    providedIn: 'root'
})

export class SideBarValidationService {

    documentDetail$ : Subject<any>;

    constructor(){
        this.documentDetail$ = new Subject();
    }

    getSideBarValidationData(): Observable<any> {
        return this.createObservableObj(sidebarJsonUrl);
    }

    createObservableObj(sidebarJsonUrl: string) {
        const sidebarData = new Observable(observer => {
            observer.next(sidebarJsonUrl);
            observer.complete();
        });
        return sidebarData;
    }

    getDocumentDetailById(id : any){
        this.documentDetail$.next(id);
    }
}
