import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-header-section',
  templateUrl: './header-section.component.html',
  styleUrls: ['./header-section.component.scss']
})
export class HeaderSectionComponent implements OnInit {

  public dropdownData: Array<any> = [
    {
      text: 'Download'
    },
    {
      text: 'Keywords'
    }
  ]

  public icon = 'cog'

  @Output() docListEvent = new EventEmitter();
  isShowDocumentListView: boolean = true;

  constructor() { }

  ngOnInit(): void {
  }

  toggleDocListView() {
    this.isShowDocumentListView = !this.isShowDocumentListView;
    this.docListEvent.emit(this.isShowDocumentListView ? 'Show' : 'Hide');
  }

  actionWasClicked(event: any) {
    console.log(event)
  }

}
