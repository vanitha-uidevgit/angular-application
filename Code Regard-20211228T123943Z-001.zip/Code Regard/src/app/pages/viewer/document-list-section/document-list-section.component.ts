import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { PageChangeEvent } from '@progress/kendo-angular-pager';
import { DataViewService } from 'src/app/services/data-view.service';
import { SideBarValidationService } from '../../../services/sidebar.service';


@Component({
  selector: 'app-document-list-section',
  templateUrl: './document-list-section.component.html',
  styleUrls: ['./document-list-section.component.scss']
})
export class DocumentListSectionComponent implements OnChanges, OnInit {

  public sidebarData: any;
  public sideDataArray: any = [];
  public pageSize = 2;
  public skip = 0;
  public pagedArticles = [];
  public pageSizes = false;
  public info = true;
  public prevNext = true;
  public total = 0;
  public type = 'numeric';
  public pagedDestinations = [];

  constructor(private sidebarService: SideBarValidationService, private dataViewService: DataViewService) { }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('docListViewStatus', changes)
    this.pageData();
  }

  public ngOnInit(): void {
    this.sidebarService.getSideBarValidationData().subscribe((data: any) => {
      if (data) {
        this.sidebarData = data;
        this.sideDataArray = data.children;
        this.total = this.sideDataArray.length;
      }
    });
  }

  public onPageChange(e: PageChangeEvent): void {
    this.skip = e.skip;
    this.pageSize = e.take;
    this.pageData();
  }

  private pageData(): void {
    this.pagedArticles = this.sideDataArray.slice(this.skip, this.skip + this.pageSize);
    console.log(this.pagedArticles, '')
  }

  public itemClicked(data: any) {
    this.dataViewService.getViewData(data);
  }


}
