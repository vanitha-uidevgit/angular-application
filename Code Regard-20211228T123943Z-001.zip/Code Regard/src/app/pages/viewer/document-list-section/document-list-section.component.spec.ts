import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentListSectionComponent } from './document-list-section.component';

describe('DocumentListSectionComponent', () => {
  let component: DocumentListSectionComponent;
  let fixture: ComponentFixture<DocumentListSectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentListSectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentListSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
