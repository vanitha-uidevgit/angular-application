import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewer',
  templateUrl: './viewer.component.html',
  styleUrls: ['./viewer.component.scss']
})
export class ViewerComponent implements OnInit {
  toggleDocListView: any = 'Show';

  constructor() { }

  ngOnInit(): void {
  }

  toggleDocListEvent(status:string){
    this.toggleDocListView = status;
  }

}
