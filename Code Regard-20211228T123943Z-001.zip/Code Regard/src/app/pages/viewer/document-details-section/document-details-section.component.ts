import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { DataViewService } from 'src/app/services/data-view.service';

@Component({
  selector: 'app-document-details-section',
  templateUrl: './document-details-section.component.html',
  styleUrls: ['./document-details-section.component.scss']
})
export class DocumentDetailsSectionComponent implements OnInit {


   public content = `<h1><p>This is formatted message</p></h1> <p style="text-align: center;">My <strong>Bold </strong>centered aligned <span style="background-color: #fce5d4; color: #c45a11;">colorful</span><span style="color: #c45a11;"> </span>text</p> <p><em>Italic</em></p> <p><span style="text-decoration-line: underline;">Underlined</span></p> <p><span style="font-size: 10pt;">With image</span></p> <p><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAnCAYAAACMo1E1AAAFe0lEQVRYCeWYa0xTZxjHT0tbKBSCwYKI0QkUL0EIdUKxrVsEBIZKy01gyDS6ubmpU0EB2wKiAScgtyrgJXEXR1w2N0WEFrBx6gQRNVmy7Nu+7sM+QPn+X86h78EezmmJwpzbh1+evO+5/fqc53nbt5SUosAgckUyfiFKKAoMIlck4wWO1Jsh90KmWGHX3OvP3H9Cjq47Phag/mZqbq6Z4xNboEb5f8opJAEojDOhPmcQ5tIuxK1MhELmP70kzbEEFixz70V9DIvOjqqNQ/i5Ywq3Gv5A82c3kKrOgb/Ed06SCyKXvDQHtXo76vQOVCUP4l7HFIut+U9Yj9gRuWS1V8F5lfMTS6FftgPVWhvqNjlQq7+LymQ77rVPzaKn5tdXl5P7yLAuPBlBskD+JYR0L0UhITQNlZqbjBQtVq0bRoXGBkfrFC/s4i5Qgx4zFxuWiLKUy2jLewhTxjUsCVwmKBgmX47ypB9Qox9mseiGcEzTD0fLFC+vJLc3rhtN2++ju+g5LhY/R/nmy1Ap4+HnI2UlpWIxVgStxUH1l6jWDbHU6IZh0Q5iv/oa7p5z8uJVjpzA/T6lx6Uxl7Av7is0Gx6iq/AZuoqeocnowLbYj+AnljE1ExEQhU/VV2DR2hkZWoiwO7YNKwLXYrjJyQt5tlCkyAE+uQ9iLqFE1Y09sVdwNnsInYXPGFrzHiFr7V4ESYOwd915mLQ2mLWDbuxe144Q33BIKBGGGp28kGcLRY9ypTEXQfO+qhNrlGrUb72DCzuesphSb6Bi4wAqkwdwYqMNJq0dxzW3ULCmBgpJINuNQ2ed4ENIisx7lNup6gbBVyRGQsQ7aMgehLXgKawF4wxN2SM4sYmWuoPDG65jfVgW5GL3RdZ+xgk+iIRQ9ChXouoCgX7ttKB+pQEdBePoyB9nY4vxMY7r+hGvTINM5MNmjDzU3uAEH+S4UPS4lJSoOkGg5eRiGXQRRahOuYvW3Cdozx93Y8uqXfCXyGfJ2eqd4ENIisx7lCuOPg+aomgr/EQS6COKcDTxJo4m3UZtqgMtuWNoy3vC0Jr3BI2G+9iRUAGlPMxNcOD0JPggEkLRi5wVRVEdKIhsQ0zwBhxY/x2OafpQpunD4cReHNn0NVpzxxhJWpSmOWcElak9CPZdxAr2n5oEH0JSZN6jXGF0OwqiWlCy6gIOqL9FeVIfw/6Eb5AQmgmFVIF92lY0GkcZsXO5YziXMwY6VqReR8xiNaQisbtY3ST6XRAJoUhJ6S0hd1voGudHtmDn6k58vuEnlCXdZtgT14mVQfFMc9A3DZGH4hPdeTQZRtBsfOyGeUsvNCuM6Ds5ib7a2QhJkXmPcsUx7Ti4/nscTexlyF91CsGyEGZhpRtk+iYiKAMiUL65B03GUTfOGkZhSXfwitGyREIozsiRDJJIUQiXRyI7uhK7Yq0wqkxYJFvM3nBGbnrDo/QPR1lKDxoNoyxfZI/gZOYD3K6Z5EVIisxPy3nY3PiJpFgkU0LhE8CKkYu5MTokHlWpP4KWomnYPoLazAfotUy6mECvZQbu9dyxVzk6QwTuxdwxXfxJy7NwKsuBM9tH0LDtEWoy7uOWeWIWVw/95vXDzqsckVVHpMGcYcPprb/AQsuZJliuHvodZYaLWBr81qvLkQdyo1vNsc1BmoTC28syYU63M3I3qyZg/fARSt81Y3W4GnIf9+9e7r3J2GvmyInc6E2O/r23WbULtYYBFOsqEKpYAj+f6d+A3HsJjafluOvcHOrMTY7sI+Z55z8jR5YQEl2CfJ+KaRDXebz/m8yT7Bsi98KrZDLjIXN0Nv+51yog5ibA6UhPx/hK4WXmFqxbX0aGew11bOAvvA7SDzWjtGPYI/9qub8BOE3bS23jIWUAAAAASUVORK5CYII=" /></p>
  <p>with very long content</p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Pellentesque nec nam aliquam sem et tortor. Vulputate dignissim suspendisse in est ante in nibh mauris. Morbi tempus iaculis urna id volutpat lacus. Ultrices neque ornare aenean euismod elementum nisi quis. Maecenas ultricies mi eget mauris pharetra et. Euismod nisi porta lorem mollis aliquam ut. Blandit turpis cursus in hac habitasse platea dictumst quisque sagittis. Quam viverra orci sagittis eu volutpat odio facilisis mauris. Et netus et malesuada fames ac turpis egestas maecenas pharetra. Tellus in hac habitasse platea dictumst vestibulum rhoncus. Eget magna fermentum iaculis eu non diam phasellus. Scelerisque fermentum dui faucibus in. Suspendisse interdum consectetur libero id faucibus nisl tincidunt. Et pharetra pharetra massa massa ultricies.</p><p>Iaculis eu non diam phasellus vestibulum lorem sed risus ultricies. Magna ac placerat vestibulum lectus. Dolor purus non enim praesent elementum facilisis leo. Volutpat consequat mauris nunc congue nisi vitae suscipit. Ut placerat orci nulla pellentesque. Hendrerit dolor magna eget est lorem ipsum dolor sit. Ultricies tristique nulla aliquet enim tortor at auctor urna. Eleifend donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum. At urna condimentum mattis pellentesque id nibh tortor id aliquet. Quis varius quam quisque id diam. Non curabitur gravida arcu ac tortor dignissim convallis aenean. Orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero. Condimentum vitae sapien pellentesque habitant morbi tristique senectus. Vitae aliquet nec ullamcorper sit amet risus nullam eget felis. At imperdiet dui accumsan sit amet nulla facilisi morbi. Mi quis hendrerit dolor magna eget.</p>
  
   <p>Message Signature <br />`;

   public getViewData: any;

  public get safeHtmlContent(): SafeHtml {
    return this.domSanitizer.bypassSecurityTrustHtml(this.content);
  }

  constructor(private dataViewService: DataViewService, private domSanitizer: DomSanitizer) { }

  ngOnInit(): void {
    this.dataViewService.dataView$.subscribe((data: any) => {
      console.log(data, 'data')
      if (data) {
        this.getViewData = data;
      }
      // use the data of your api
    })
  }


  

}
