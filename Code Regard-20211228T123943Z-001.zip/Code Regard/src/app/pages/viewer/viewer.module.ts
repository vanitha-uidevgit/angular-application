import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewerRoutingModule } from './viewer-routing.module';
import { ViewerComponent } from './viewer.component';
import { HeaderSectionComponent } from './header-section/header-section.component';
import { DocumentListSectionComponent } from './document-list-section/document-list-section.component';
import { DocumentDetailsSectionComponent } from './document-details-section/document-details-section.component';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { PagerModule } from '@progress/kendo-angular-pager';
import { EditorModule } from '@progress/kendo-angular-editor';

@NgModule({
  declarations: [ViewerComponent, HeaderSectionComponent, DocumentListSectionComponent, DocumentDetailsSectionComponent],
  imports: [
    CommonModule,
    ViewerRoutingModule,
    LayoutModule,
    ButtonsModule,
    PagerModule,
    IconsModule,
    EditorModule
  ]
})
export class ViewerModule { }
